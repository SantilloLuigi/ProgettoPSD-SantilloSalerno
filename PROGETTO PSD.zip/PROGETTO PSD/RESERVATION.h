#ifndef RESERVATION_H
#define RESERVATION_H

/*
    Dichiariamo la struttura Reservation in modo incompleto
    per nascondere i dettagli interni
    dell'implementazione agli altri file del programma.

    In questo modo applichiamo l'information hiding:
    chi utilizza il modulo puo' usare il tipo Reservation
    senza conoscerne i campi interni.
*/
typedef struct Reservation Reservation;

/*

    Creiamo dinamicamente una nuova prenotazione
    inizializzando tutti i campi necessari.

    Restituiamo un puntatore perche' la struttura
    viene allocata dinamicamente in memoria.
*/
Reservation* res_create(int, const char*, int, int);

/*
    int res_get_matricola(const Reservation* r)

    Restituiamo la matricola associata alla prenotazione.

    Utilizziamo const Reservation* per garantire
    che la funzione non modifichi la struttura.
*/
int res_get_matricola(const Reservation*);

/*
    void res_set_checked(Reservation* r, int valore)

    Modifichiamo lo stato di controllo della prenotazione.

    Utilizziamo questa funzione setter per aggiornare
    il campo senza accedere direttamente alla struttura interna.
*/
void res_set_checked(Reservation*, int);

/*
    int res_get_checked(const Reservation* r)

    Restituiamo lo stato della prenotazione
    (ad esempio confermata o controllata).

    Utilizziamo una funzione getter per mantenere
    l'incapsulamento dei dati.
*/
int res_get_checked(const Reservation*);

/*
    void res_save(const Reservation* r, FILE* f)

    Salviamo una prenotazione all'interno di un file.

    Utilizziamo FILE* per lavorare con file gia' aperti
    dal chiamante, rendendo la funzione piu' flessibile.
*/
void res_save(const Reservation*, FILE*);

/*
    Reservation* res_load(FILE* f)

    Carichiamo una prenotazione leggendo i dati dal file.

    Restituiamo un puntatore alla nuova prenotazione
    creata dinamicamente durante la lettura.
*/
Reservation* res_load(FILE*);

/*
    void res_destroy(Reservation* r)

    Liberiamo la memoria associata alla prenotazione.

    Utilizziamo questa funzione per evitare memory leak
    causati dall'allocazione dinamica.
*/
void res_destroy(Reservation*);

#endif