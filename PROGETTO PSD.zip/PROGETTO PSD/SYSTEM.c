#include <stdio.h>
#include <stdlib.h>
#include "system.h"

#define FILE_STUDENTI "studenti.txt"
/* Nome del file che utilizziamo per salvare gli studenti */

#define FILE_PRENOT "prenotazioni.txt"
/* File che utilizziamo per memorizzare le prenotazioni */

#define FILE_STORICO "storico.txt"
/* File che contiene lo storico di check-in/check-out */

/*
 * Struttura principale del sistema.
 * Contiene:
 * - lista studenti
 * - array dinamico di prenotazioni
 * - numero totale di prenotazioni
 */
struct System {
    StudentList* studenti;
    Reservation** pren;
    int n;
};

/*
 * System* system_load();
 * Carichiamo studenti e prenotazioni dai file.
 * La utilizziamo per ripristinare i dati salvati all'avvio del programma.
 */
System* system_load() {

    /* Allochiamo dinamicamente la struttura del sistema */
    System* s = malloc(sizeof(System));

    s->pren = NULL;
    s->n = 0;

    /*
     * fopen(...,"r")
     * Apriamo il file in modalita' lettura.
     * Lo utilizziamo per recuperare i dati salvati.
     */
    FILE* f = fopen(FILE_STUDENTI,"r");
    s->studenti = f ? sl_load(f) : sl_create();

    /*
     * fclose(FILE* f)
     * Chiudiamo il file liberando le risorse associate.
     */
    if(f) fclose(f);

    f = fopen(FILE_PRENOT,"r");

    if(f){

        Reservation* r;

        /*
         * Carichiamo una prenotazione alla volta
         * finche' res_load restituisce un valore valido.
         */
        while((r = res_load(f))){

            /*
             * realloc ridimensiona dinamicamente l'array.
             * Lo utilizziamo per aggiungere nuove prenotazioni
             * senza conoscere in anticipo la dimensione totale.
             */
            s->pren = realloc(s->pren, sizeof(Reservation*)*(s->n+1));

            s->pren[s->n++] = r;
        }

        fclose(f);
    }

    return s;
}

/*
 * void system_save(System* s);
 * Salviamo studenti e prenotazioni nei file.
 */
void system_save(System* s){

    FILE* f = fopen(FILE_STUDENTI,"w");

    sl_save(s->studenti,f);

    fclose(f);

    f = fopen(FILE_PRENOT,"w");

    for(int i=0;i<s->n;i++)
        res_save(s->pren[i],f);

    fclose(f);
}

/*
 * void system_destroy(System* s);
 * Liberiamo tutta la memoria allocata dinamicamente.
 * La utilizziamo per evitare memory leak.
 */
void system_destroy(System* s) {

    /*
     * Distruggiamo ogni prenotazione salvata.
     */
    for(int i=0;i<s->n;i++)
        res_destroy(s->pren[i]);

    /*
     * free(void* ptr)
     * Liberiamo la memoria allocata con malloc/realloc.
     */
    free(s->pren);

    sl_destroy(s->studenti);

    free(s);
}

/*
 * void system_register_student(System* s, int m, const char* nome, const char* corso);
 * Registriamo uno studente nel sistema.
 * La utilizziamo per aggiungere nuovi studenti alla lista.
 */
void system_register_student(System* s, int m, const char* nome, const char* corso) {

    sl_add(s->studenti, student_create(m,nome,corso));
}

/*
 * void system_book(System* s, int m, const char* data, int fascia);
 * Creiamo una nuova prenotazione.
 * La utilizziamo per associare uno studente a una fascia oraria.
 */
void system_book(System* s, int m, const char* data, int fascia) {

    s->pren = realloc(s->pren, sizeof(Reservation*)*(s->n+1));

    s->pren[s->n++] = res_create(m,data,fascia,s->n+1);
}

/*
 * void system_checkin(System* s, int m);
 * Registriamo l'ingresso dello studente.
 * La utilizziamo per salvare lo storico degli accessi.
 */
void system_checkin(System* s, int m) {

    FILE* f = fopen(FILE_STORICO,"a");

    fprintf(f,"IN %d\n",m);

    fclose(f);

    printf("Check-in registrato\n");
}

/*
 * void system_checkout(System* s, int m);
 * Registriamo l'uscita dello studente.
 * La utilizziamo per aggiornare lo storico accessi.
 */
void system_checkout(System* s, int m) {

    FILE* f = fopen(FILE_STORICO,"a");

    fprintf(f,"OUT %d\n",m);

    fclose(f);

    printf("Check-out registrato\n");
}

/*
 * void system_report(System* s);
 * Generiamo un report generale del sistema.
 * Lo utilizziamo per mostrare statistiche e accessi registrati.
 */
void system_report(System* s) {

    printf("\nTotale prenotazioni: %d\n", s->n);

    FILE* f = fopen(FILE_STORICO,"r");

    if(!f) return;

    int accessi=0;
    char tipo[10];
    int m;

    while(fscanf(f,"%s %d",tipo,&m)!=EOF)

        /*
         * Contiamo solamente i record di ingresso ("IN").
         */
        if(tipo[0]=='I') accessi++;

    fclose(f);

    printf("Accessi effettuati: %d\n", accessi);
}