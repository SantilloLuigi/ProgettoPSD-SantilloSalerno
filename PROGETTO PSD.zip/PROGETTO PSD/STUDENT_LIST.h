#ifndef STUDENT_LIST_H
#define STUDENT_LIST_H

#include "student.h"

/*
    Dichiariamo la struttura StudentList in modo incompleto
    per nascondere i dettagli implementativi
    all'esterno del modulo.

    In questo modo realizziamo l'information hiding:
    chi utilizza la libreria puo' usare il tipo StudentList
    senza conoscerne la struttura interna.
*/
typedef struct StudentList StudentList;

/*
    StudentList* sl_create()

    Creiamo e inizializziamo una nuova lista di studenti.

    Restituiamo un puntatore alla lista perche' la struttura
    verra' generalmente allocata dinamicamente.
*/
StudentList* sl_create();

/*
    void sl_add(StudentList* lista, Student* s)

    Aggiungiamo uno studente alla lista.

    Utilizziamo un puntatore alla lista per poter modificare
    direttamente la struttura originale senza copiarla.
*/
void sl_add(StudentList*, Student*);

/*
    Student* sl_find(StudentList* lista, int matricola)

    Cerchiamo uno studente nella lista tramite la matricola.

    Restituiamo un puntatore a Student per poter accedere
    direttamente allo studente trovato senza crearne una copia.
*/
Student* sl_find(StudentList*, int);

/*
    void sl_save(StudentList* lista, FILE* f)

    Salviamo tutti gli studenti presenti nella lista nel file.

    Utilizziamo FILE* per lavorare con file gia' aperti
    dal chiamante, rendendo la funzione piu' flessibile.
*/
void sl_save(StudentList*, FILE*);

/*
    StudentList* sl_load(FILE* f)

    Carichiamo una lista di studenti leggendo i dati dal file.

    Restituiamo una nuova lista perche' durante il caricamento
    vengono creati dinamicamente nuovi elementi.
*/
StudentList* sl_load(FILE*);

/*
    void sl_destroy(StudentList* lista)

    Liberiamo tutta la memoria associata alla lista,
    compresi gli eventuali studenti contenuti.

    Utilizziamo questa funzione per evitare memory leak
    dovuti all'allocazione dinamica.
*/
void sl_destroy(StudentList*);

#endif