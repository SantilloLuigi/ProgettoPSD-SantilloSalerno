#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/*
    Definiamo la struttura Student in modo privato nel file .c
    per nascondere i dettagli implementativi all'esterno.
*/
struct Student {
    int matricola;
    char nome[50];
    char corso[50];
};

/*
    Student* student_create(int m, const char* nome, const char* corso)

    Creiamo dinamicamente uno studente e inizializziamo i campi
    della struttura con i valori passati come parametri.

    Utilizziamo malloc(sizeof(Student)) per allocare memoria
    dinamicamente, cosi' l'oggetto continuera' ad esistere anche
    dopo la fine della funzione.

    Utilizziamo strcpy(dest, src) per copiare le stringhe nei
    campi della struttura, perche' in C non possiamo assegnare
    direttamente array di char con '='.
*/
Student* student_create(int m, const char* nome, const char* corso) {
    Student* s = malloc(sizeof(Student));

    s->matricola = m;

    strcpy(s->nome, nome);
    strcpy(s->corso, corso);

    return s;
}

/*
    int student_get_matricola(const Student* s)

    Restituiamo la matricola dello studente.
*/
int student_get_matricola(const Student* s) {
    return s->matricola;
}

/*
    const char* student_get_nome(const Student* s)

    Restituiamo il nome dello studente.
*/
const char* student_get_nome(const Student* s) {
    return s->nome;
}

/*
    const char* student_get_corso(const Student* s)

    Restituiamo il corso associato allo studente.
*/
const char* student_get_corso(const Student* s) {
    return s->corso;
}

/*
    void student_save(const Student* s, FILE* f)

    Salviamo i dati dello studente nel file passato come parametro.
*/
void student_save(const Student* s, FILE* f) {
    fprintf(f, "%d %s %s\n",
            s->matricola,
            s->nome,
            s->corso);
}

/*
    Student* student_load(FILE* f)

    Leggiamo i dati di uno studente dal file e creiamo
    una nuova struttura Student.

    Controlliamo che fscanf restituisca 3 perche' ci aspettiamo
    di leggere esattamente tre valori:
    matricola, nome e corso.

    Se la lettura fallisce restituiamo NULL per segnalare
    un errore o la fine del file.
*/
Student* student_load(FILE* f) {

    int m;
    char nome[50], corso[50];

    if (fscanf(f, "%d %s %s", &m, nome, corso) != 3)
        return NULL;

    return student_create(m, nome, corso);
}

/*
    void student_destroy(Student* s)

    Liberiamo la memoria allocata dinamicamente per evitare
    memory leak.

    Utilizziamo free(ptr) perche' la struttura e' stata creata
    precedentemente con malloc().
*/
void student_destroy(Student* s) {
    free(s);
}