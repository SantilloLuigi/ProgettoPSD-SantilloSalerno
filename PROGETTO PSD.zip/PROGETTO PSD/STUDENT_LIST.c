#include <stdio.h>
#include <stdlib.h>
#include "student_list.h"

/*
    Definiamo un nodo della lista concatenata.

    Ogni nodo contiene:
    - un puntatore ad uno studente
    - un puntatore al nodo successivo

    Utilizziamo una lista concatenata per gestire
    dinamicamente un numero variabile di studenti.
*/
typedef struct Node {
    Student* s;
    struct Node* next;
} Node;

/*
    La struttura StudentList contiene il puntatore
    alla testa della lista.

    head punta al primo elemento della lista concatenata.
*/
struct StudentList {
    Node* head;
};

/*
    StudentList* sl_create()

    Creiamo una nuova lista vuota.

    Utilizziamo malloc(sizeof(StudentList))
    per allocare dinamicamente la struttura,
    cosi' la lista rimane valida anche fuori
    dalla funzione.

    Inizializziamo head a NULL per indicare
    che la lista inizialmente e' vuota.
*/
StudentList* sl_create() {

    StudentList* l = malloc(sizeof(StudentList));

    l->head = NULL;

    return l;
}

/*
    void sl_add(StudentList* l, Student* s)

    Aggiungiamo uno studente all'inizio della lista.

    Creiamo un nuovo nodo dinamicamente tramite malloc()
    perche' la dimensione della lista puo' crescere
    durante l'esecuzione del programma.

    Inseriamo il nodo in testa perche' questa operazione
    e' veloce e non richiede di attraversare tutta la lista.
*/
void sl_add(StudentList* l, Student* s) {

    Node* n = malloc(sizeof(Node));

    n->s = s;

    n->next = l->head;

    l->head = n;
}

/*
    Student* sl_find(StudentList* l, int m)

    Cerchiamo uno studente tramite matricola.

    Utilizziamo un puntatore cur per scorrere
    la lista nodo per nodo.

    student_get_matricola() viene utilizzata
    per accedere correttamente al dato dello studente
    senza conoscere la struttura interna di Student.

    Se troviamo lo studente restituiamo il puntatore,
    altrimenti restituiamo NULL.
*/
Student* sl_find(StudentList* l, int m) {

    Node* cur = l->head;

    while(cur) {

        if(student_get_matricola(cur->s) == m)
            return cur->s;

        cur = cur->next;
    }

    return NULL;
}

/*
    void sl_save(StudentList* l, FILE* f)

    Salviamo tutti gli studenti presenti nella lista nel file.

    Scorriamo la lista utilizzando il puntatore cur.

    Utilizziamo student_save() per delegare il salvataggio
    del singolo studente al modulo Student,
    mantenendo separati i compiti dei moduli.
*/
void sl_save(StudentList* l, FILE* f) {

    Node* cur = l->head;

    while(cur) {

        student_save(cur->s, f);

        cur = cur->next;
    }
}

/*
    StudentList* sl_load(FILE* f)

    Carichiamo gli studenti dal file e li inseriamo nella lista.

    Utilizziamo student_load() per leggere un singolo studente
    dal file.

    Il ciclo continua finche' student_load()
    non restituisce NULL, cioe' quando termina la lettura
    o si verifica un errore.

    Creiamo inizialmente una lista vuota tramite sl_create().
*/
StudentList* sl_load(FILE* f) {

    StudentList* l = sl_create();

    Student* s;

    while((s = student_load(f)) != NULL)
        sl_add(l, s);

    return l;
}

/*
    void sl_destroy(StudentList* l)

    Liberiamo tutta la memoria associata alla lista.

    Scorriamo ogni nodo della lista:
    - liberiamo prima lo studente tramite student_destroy()
    - poi liberiamo il nodo con free()

    Utilizziamo una variabile temporanea tmp
    per conservare il nodo corrente prima di avanzare
    al successivo.

    Alla fine liberiamo anche la struttura StudentList.
*/
void sl_destroy(StudentList* l) {

    Node* cur = l->head;

    while(cur) {

        Node* tmp = cur;

        student_destroy(cur->s);

        cur = cur->next;

        free(tmp);
    }

    free(l);
}