#ifndef STUDENT_H
#define STUDENT_H

/*
 * Struttura opaca dello studente.
 * La utilizziamo per nascondere i dettagli interni
 * e permettere l'accesso ai dati solo tramite funzioni dedicate.
 */
typedef struct Student Student;

/*
 * Student* student_create(int matricola, const char* nome, const char* corso);
 * Creiamo dinamicamente uno studente.
 * La utilizziamo per inizializzare un nuovo record studente.
 */
Student* student_create(int, const char*, const char*);

/*
 * int student_get_matricola(const Student* s);
 * Restituiamo la matricola dello studente.
 * La utilizziamo per identificare univocamente uno studente.
 */
int student_get_matricola(const Student*);

/*
 * const char* student_get_nome(const Student* s);
 * Restituiamo il nome dello studente.
 */
const char* student_get_nome(const Student*);

/*
 * const char* student_get_corso(const Student* s);
 * Restituiamo il corso dello studente.
 */
const char* student_get_corso(const Student*);

/*
 * void student_save(const Student* s, FILE* f);
 * Salviamo lo studente all'interno di un file.
 * La utilizziamo per mantenere persistenti i dati.
 */
void student_save(const Student*, FILE*);

/*
 * Student* student_load(FILE* f);
 * Carichiamo uno studente da file.
 * La utilizziamo per recuperare dati precedentemente salvati.
 */
Student* student_load(FILE*);

/*
 * void student_destroy(Student* s);
 * Liberiamo la memoria allocata per lo studente.
 * La utilizziamo per evitare memory leak.
 */
void student_destroy(Student*);

#endif