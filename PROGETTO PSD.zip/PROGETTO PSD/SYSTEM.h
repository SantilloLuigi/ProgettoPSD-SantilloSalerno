#ifndef SYSTEM_H
#define SYSTEM_H

#include "student_list.h"
#include "reservation.h"

/*
 * Struttura opaca del sistema.
 * La usiamo per nascondere i dettagli interni della struttura
 * e permettere l'accesso solo tramite funzioni dedicate in modo da garantire information hiding.
 */
typedef struct System System;

// lifecycle

/*
 * System* system_load();
 * Carichiamo il sistema e restituiamo un puntatore alla struttura System.
 * che utilizziamo per inizializzare il programma in modo da recuperare eventuali dati salvati.
 */
System* system_load();

/*
 * void system_save(System* s);
 * Salviamo lo stato corrente del sistema.
 * La utilizziamo per mantenere persistenti dati e prenotazioni.
 */
void system_save(System*);

/*
 * void system_destroy(System* s);
 * Liberiamo la memoria allocata per il sistema.
 * Necessaria per evitare memory leak. ( spreco di memoria e eventuali bug/side effect)
 */
void system_destroy(System*);

// operazioni

/*
 * void system_register_student(System* s, int id, const char* nome, const char* cognome);
 *  Con la funzione registriamo uno studente nel sistema.
 * Serve per aggiungere un nuovo studente alla lista.
 * Le stringhe sono const perchÃ© non devono essere modificate.
 */
void system_register_student(System*, int, const char*, const char*);

/*
 * void system_book(System* s, int id, const char* data, int posto);
 * Con la funzione effettuiamo una prenotazione per uno studente.
 * La utilizziamo per associare uno studente a una data e un posto.
 */
void system_book(System*, int, const char*, int);

/*
 * void system_checkin(System* s, int id);
 * Con la Funzione registriamo l'ingresso dello studente.
 * Serve per segnalare la presenza in aula.
 */
void system_checkin(System*, int);

/*
 * void system_checkout(System* s, int id);
 *Con la funzione registriamo l'uscita dello studente.
 * La utilizziamo per aggiornare lo stato della presenza.
 */
void system_checkout(System*, int);
/*
 * void system_report(System* s);
 * Generiamo un report del sistema.
 * Serve per visualizzare informazioni e stato generale.( esempio: accessi effettuati, num. totale di prenotazioni, occupazioni fasce orarie, studenti assenti, studenti in attesa)
 */
void system_report(System*);
#endif