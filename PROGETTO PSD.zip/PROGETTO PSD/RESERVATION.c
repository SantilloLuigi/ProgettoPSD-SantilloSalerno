#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "reservation.h"

/*
    Definiamo la struttura Reservation in modo privato
    all'interno del file .c per nascondere i dettagli
    implementativi agli altri moduli.

    La struttura contiene:
    - matricola dello studente
    - data della prenotazione
    - fascia oraria
    - numero del posto
    - stato di check della prenotazione
*/
struct Reservation {

    int matricola;

    char data[20];

    int fascia;

    int posto;

    int checked;
};

/*

    Creiamo dinamicamente una nuova prenotazione
    inizializzando tutti i campi della struttura.

    Utilizziamo malloc(sizeof(Reservation))
    per allocare memoria dinamicamente,
    cosi' la prenotazione continua ad esistere
    anche dopo il termine della funzione.

    Utilizziamo strcpy(dest, src)
    per copiare la stringa della data,
    perche' gli array di char non possono
    essere assegnati direttamente con '='.

    Inizializziamo checked a 0 per indicare
    che la prenotazione non e' ancora stata verificata.
*/
Reservation* res_create(int m, const char* d, int f, int p) {

    Reservation* r = malloc(sizeof(Reservation));

    r->matricola = m;

    strcpy(r->data, d);

    r->fascia = f;

    r->posto = p;

    r->checked = 0;

    return r;
}

/*
    int res_get_matricola(const Reservation* r)

    Restituiamo la matricola associata
    alla prenotazione.

    Utilizziamo const Reservation*
    per evitare modifiche accidentali
    alla struttura.
*/
int res_get_matricola(const Reservation* r) {
    return r->matricola;
}

/*
    int res_get_checked(const Reservation* r)

    Restituiamo lo stato di controllo
    della prenotazione.
*/
int res_get_checked(const Reservation* r) {
    return r->checked;
}

/*
    void res_set_checked(Reservation* r, int v)

    Modifichiamo il valore del campo checked.

    Utilizziamo una funzione setter
    per mantenere l'incapsulamento
    dei dati della struttura.
*/
void res_set_checked(Reservation* r, int v) {
    r->checked = v;
}

/*
    void res_save(const Reservation* r, FILE* f)

    Salviamo i dati della prenotazione nel file.

    Utilizziamo fprintf(FILE*, formato, ...)
    per scrivere dati formattati nel file
    in modo leggibile e ordinato.
*/
void res_save(const Reservation* r, FILE* f) {

    fprintf(f, "%d %s %d %d %d\n",
            r->matricola,
            r->data,
            r->fascia,
            r->posto,
            r->checked);
}

/*
    Reservation* res_load(FILE* f)

    Leggiamo una prenotazione dal file
    e creiamo dinamicamente una nuova struttura.

    Controlliamo che fscanf restituisca 5
    perche' ci aspettiamo di leggere:
    - matricola
    - data
    - fascia
    - posto
    - stato checked

    Se la lettura fallisce restituiamo NULL
    per segnalare un errore o la fine del file.

    Dopo la creazione aggiorniamo il campo checked
    con il valore letto dal file.
*/
Reservation* res_load(FILE* f) {

    int m, fasc, p, c;

    char d[20];

    if(fscanf(f, "%d %s %d %d %d",
              &m, d, &fasc, &p, &c) != 5)
        return NULL;

    Reservation* r = res_create(m, d, fasc, p);

    r->checked = c;

    return r;
}

/*
    void res_destroy(Reservation* r)

    Liberiamo la memoria allocata dinamicamente
    per la prenotazione.

    Utilizziamo free(ptr) perche' la struttura
    e' stata precedentemente creata con malloc().
*/
void res_destroy(Reservation* r) {
    free(r);
}