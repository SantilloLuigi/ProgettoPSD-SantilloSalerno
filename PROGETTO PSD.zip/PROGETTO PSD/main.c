#include <stdio.h>
#include <string.h>
#include "system.h"

/*
    void menu()

    Mostriamo il menu principale del programma.

*/
void menu() {

    printf("\n=== AULA STUDIO ===\n");

    printf("1. Registra studente\n");

    printf("2. Prenota posto\n");

    printf("3. Check-in\n");

    printf("4. Check-out\n");

    printf("5. Report\n");

    printf("6. Esegui test da file\n");

    printf("0. Esci\n");
}

/*
    void esegui_test_file(System* sys, const char* filename)

    Eseguiamo automaticamente una sequenza di comandi
    leggendo le istruzioni da un file.

    Se fopen() restituisce NULL significa
    che il file non e' stato aperto correttamente.
*/
void esegui_test_file(System* sys, const char* filename) {

    FILE* f = fopen(filename, "r");

    if(!f) {

        printf("Errore apertura file\n");

        return;
    }

    /*
        cmd contiene il comando letto dal file
        (esempio: REG, BOOK, IN, OUT, REPORT).
    */
    char cmd[20];

    /*
        Il ciclo continua fino alla fine del file (EOF).
    */
    while(fscanf(f, "%s", cmd) != EOF) {

        /*
            strcmp(str1, str2) confronta due stringhe.

            Se restituisce 0 significa che le stringhe
            sono uguali.
        */
        if(strcmp(cmd, "REG") == 0) {

            int m;

            char nome[50], corso[50];

            /*
                Leggiamo matricola, nome e corso
                dal file e registriamo lo studente.
            */
            fscanf(f, "%d %s %s", &m, nome, corso);

            system_register_student(sys, m, nome, corso);
        }

        else if(strcmp(cmd, "BOOK") == 0) {

            int m, fascia;

            char data[20];

            /*
                Leggiamo i dati necessari
                per effettuare una prenotazione.
            */
            fscanf(f, "%d %s %d", &m, data, &fascia);

            system_book(sys, m, data, fascia);
        }

        else if(strcmp(cmd, "IN") == 0) {

            int m;

            fscanf(f, "%d", &m);

            system_checkin(sys, m);
        }

        else if(strcmp(cmd, "OUT") == 0) {

            int m;

            fscanf(f, "%d", &m);

            system_checkout(sys, m);
        }

        else if(strcmp(cmd, "REPORT") == 0) {

            /*
                Generiamo il report del sistema.
            */
            system_report(sys);
        }
    }

    /*
        Utilizziamo fclose(FILE*)
        per chiudere il file e liberare
        le risorse associate.
    */
    fclose(f);

    printf("Test da file completato.\n");
}

/*
    int main()

    Funzione principale del programma.

    Gestiamo il menu interattivo dell'aula studio
    e le operazioni richieste dall'utente.
*/
int main() {

    /*
        Carichiamo i dati salvati in precedenza.

        system_load() permette di ripristinare
        studenti e prenotazioni da file.
    */
    System* sys = system_load();

    int scelta;

    /*
        Utilizziamo un ciclo do-while
        perche' il menu deve essere mostrato
        almeno una volta.
    */
    do {

        menu();

        printf("Scelta: ");
        scanf("%d", &scelta);

        if(scelta == 1) {

            int m;

            char nome[50], corso[50];

            printf("Matricola: ");
            scanf("%d", &m);

            printf("Nome: ");
            scanf("%s", nome);

            printf("Corso: ");
            scanf("%s", corso);

            /*
                Registriamo un nuovo studente
                nel sistema.
            */
            system_register_student(sys, m, nome, corso);
        }

        else if(scelta == 2) {

            int m, fascia;

            char data[20];

            printf("Matricola: ");
            scanf("%d", &m);

            printf("Data: ");
            scanf("%s", data);

            printf("Fascia: ");
            scanf("%d", &fascia);

            /*
                Effettuiamo una prenotazione
                per lo studente indicato.
            */
            system_book(sys, m, data, fascia);
        }

        else if(scelta == 3) {

            int m;

            printf("Matricola: ");

            scanf("%d", &m);

            /*
                Segniamo l'ingresso dello studente.
            */
            system_checkin(sys, m);
        }

        else if(scelta == 4) {

            int m;

            printf("Matricola: ");

            scanf("%d", &m);

            /*
                Segniamo l'uscita dello studente.
            */
            system_checkout(sys, m);
        }

        else if(scelta == 5) {

            /*
                Mostriamo il report generale
                del sistema.
            */
            system_report(sys);
        }

        else if(scelta == 6) {

            char file[50];

            printf("Nome file test: ");

            scanf("%s", file);

            /*
                Eseguiamo automaticamente
                i comandi presenti nel file.
            */
            esegui_test_file(sys, file);
        }

    } while(scelta != 0);

    /*
        Salviamo i dati prima della chiusura
        del programma.
    */
    system_save(sys);

    /*
        Liberiamo tutta la memoria utilizzata
        dal sistema.
    */
    system_destroy(sys);

    printf("Dati salvati. Uscita...\n");

    return 0;
}